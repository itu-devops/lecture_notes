As it was back in the days, not really all code was collected during the session.

The feature of not showing flagged tweets in the _ITU-MiniTwit_ UI is actually not completely implemented in the application. The patch that one of the developers sent via email was still hanging in the inbox and appeared first now.

To apply it to `minitwit.py` you can use the `patch` command as described in the corresponding `man` page.